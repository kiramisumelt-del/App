import { Task, AppNotification } from '../types/todo';

export function isNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

export function getNotificationPermission(): NotificationPermission {
  if (!isNotificationSupported()) return 'denied';
  return Notification.permission;
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (!isNotificationSupported()) return false;
  try {
    const result = await Notification.requestPermission();
    return result === 'granted';
  } catch {
    return false;
  }
}

export function sendBrowserNotification(title: string, options?: NotificationOptions): boolean {
  if (!isNotificationSupported() || Notification.permission !== 'granted') {
    return false;
  }
  try {
    new Notification(title, {
      icon: '/src/assets/images/mascot_bunny_avatar_1791959065082.jpg',
      badge: '/src/assets/images/mascot_bunny_avatar_1791959065082.jpg',
      ...options,
    });
    return true;
  } catch (err) {
    console.warn('Browser notification failed to trigger', err);
    return false;
  }
}

export function generateTaskNotifications(tasks: Task[]): AppNotification[] {
  const todayStr = new Date().toISOString().split('T')[0];
  const notifications: AppNotification[] = [];

  tasks.forEach((task) => {
    if (task.completed || !task.dueDate) return;

    if (task.dueDate < todayStr) {
      notifications.push({
        id: `notif-overdue-${task.id}`,
        taskId: task.id,
        taskTitle: task.title,
        type: 'overdue',
        date: task.dueDate,
        read: false,
      });
    } else if (task.dueDate === todayStr) {
      notifications.push({
        id: `notif-today-${task.id}`,
        taskId: task.id,
        taskTitle: task.title,
        type: 'due_today',
        date: task.dueDate,
        read: false,
      });
    }
  });

  return notifications;
}
