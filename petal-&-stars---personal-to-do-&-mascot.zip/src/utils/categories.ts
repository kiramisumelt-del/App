import { Category } from '../types/todo';

export const DEFAULT_CATEGORIES: Category[] = [
  {
    id: 'personal',
    name: 'Personal & Fits',
    icon: 'Heart',
    color: '#8A5D6F', // Dusty mauve
    bgColor: '#F5E7ED',
    borderColor: '#E7D1DA',
  },
  {
    id: 'study',
    name: 'Studio & Work',
    icon: 'Terminal',
    color: '#3B607A', // Slate blue
    bgColor: '#E6EFF5',
    borderColor: '#D9E4EC',
  },
  {
    id: 'creative',
    name: 'Design & Visuals',
    icon: 'Palette',
    color: '#606362', // Slate charcoal
    bgColor: '#FBF9F2',
    borderColor: '#E2DDD4',
  },
  {
    id: 'wellness',
    name: 'Routines & Life',
    icon: 'Activity',
    color: '#494D4B', // Deep charcoal
    bgColor: '#EDEBE6',
    borderColor: '#D8D4CC',
  },
  {
    id: 'errands',
    name: 'Errands & Drops',
    icon: 'Package',
    color: '#5C3854', // Plum
    bgColor: '#F2E4ED',
    borderColor: '#E3C8D9',
  },
];

export const PRIORITY_CONFIG = {
  urgent: {
    label: 'Urgent',
    color: '#D44355',
    bgColor: '#FDECEF',
    borderColor: '#F6BCC5',
    textColor: '#A02535',
    icon: 'Flame',
    weight: 4,
  },
  high: {
    label: 'High',
    color: '#C9772B',
    bgColor: '#FDF1E6',
    borderColor: '#F9D0AF',
    textColor: '#8C480D',
    icon: 'AlertCircle',
    weight: 3,
  },
  medium: {
    label: 'Medium',
    color: '#3B607A',
    bgColor: '#E6EFF5',
    borderColor: '#D9E4EC',
    textColor: '#274357',
    icon: 'Clock',
    weight: 2,
  },
  low: {
    label: 'Low',
    color: '#606362',
    bgColor: '#F4F2EB',
    borderColor: '#E2DDD4',
    textColor: '#474A49',
    icon: 'Minus',
    weight: 1,
  },
} as const;
