import { Task, Category } from '../types/todo';
import { DEFAULT_CATEGORIES } from './categories';

const STORAGE_KEY = 'acubi_matrix_tasks_v2';
const CATEGORIES_STORAGE_KEY = 'acubi_matrix_categories_v1';

export const SAMPLE_TASKS: Task[] = [
  {
    id: 'sample-1',
    title: 'Select chrome silver jewelry & layered chain accessories',
    description: 'Finalize styling accents and metallic rings for upcoming shoot.',
    completed: false,
    priority: 'high',
    category: 'personal',
    dueDate: new Date().toISOString().split('T')[0], // Today
    dueTime: '15:30',
    createdAt: new Date(Date.now() - 3600000 * 3).toISOString(),
    tags: ['FitCheck', 'Acubi', 'Silver'],
    subtasks: [
      { id: 'sub-1', title: 'Pick heavy link chain and star pendant', completed: true },
      { id: 'sub-2', title: 'Coordinate dark charcoal distressed knit', completed: false },
    ],
    estimatedMinutes: 30,
  },
  {
    id: 'sample-2',
    title: 'Curate Acubi streetwear mood board & editorial layout',
    description: 'Collect minimal Y2K cyber-grunge references, typography, and contrast boards.',
    completed: true,
    completedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    priority: 'medium',
    category: 'creative',
    dueDate: new Date().toISOString().split('T')[0],
    dueTime: '11:00',
    createdAt: new Date(Date.now() - 3600000 * 10).toISOString(),
    tags: ['Moodboard', 'Visuals'],
    subtasks: [
      { id: 'sub-21', title: 'Scan texture swatches', completed: true },
      { id: 'sub-22', title: 'Arrange 4-column monochrome grid', completed: true },
    ],
    estimatedMinutes: 45,
  },
  {
    id: 'sample-3',
    title: 'Digital studio color grade & chrome typography pass',
    description: 'Export hi-res campaign stills with brushed metallic text overlays.',
    completed: false,
    priority: 'urgent',
    category: 'study',
    dueDate: new Date().toISOString().split('T')[0], // Today
    dueTime: '18:00',
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    tags: ['Studio', 'ColorGrade'],
    subtasks: [
      { id: 'sub-31', title: 'Grade shadows to cool slate black', completed: false },
      { id: 'sub-32', title: 'Render silver star vectors', completed: false },
    ],
    estimatedMinutes: 60,
  },
  {
    id: 'sample-4',
    title: 'Review weekly drop schedule & packaging details',
    description: 'Check batch delivery timeline, matte black poly mailers, and custom tags.',
    completed: false,
    priority: 'medium',
    category: 'errands',
    dueDate: new Date(Date.now() + 86400000).toISOString().split('T')[0], // Tomorrow
    dueTime: '14:00',
    createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
    tags: ['Drop', 'Logistics'],
    subtasks: [],
    estimatedMinutes: 20,
  },
  {
    id: 'sample-5',
    title: 'Late night calm routine & hydration reset',
    description: 'Unwind from screen glare, iced matcha or herbal tea, reset workspace.',
    completed: false,
    priority: 'low',
    category: 'wellness',
    dueDate: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
    createdAt: new Date(Date.now() - 3600000 * 16).toISOString(),
    tags: ['Routine', 'Night'],
    subtasks: [],
    estimatedMinutes: 15,
  },
];

export function loadTasksFromStorage(): Task[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveTasksToStorage(SAMPLE_TASKS);
      return SAMPLE_TASKS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return SAMPLE_TASKS;
  } catch (err) {
    console.warn('Failed to load tasks from localStorage', err);
    return SAMPLE_TASKS;
  }
}

export function saveTasksToStorage(tasks: Task[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  } catch (err) {
    console.error('Failed to save tasks to localStorage', err);
  }
}

export function loadCategoriesFromStorage(): Category[] {
  try {
    const raw = localStorage.getItem(CATEGORIES_STORAGE_KEY);
    if (!raw) {
      saveCategoriesToStorage(DEFAULT_CATEGORIES);
      return DEFAULT_CATEGORIES;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return DEFAULT_CATEGORIES;
  } catch (err) {
    console.warn('Failed to load categories from localStorage', err);
    return DEFAULT_CATEGORIES;
  }
}

export function saveCategoriesToStorage(categories: Category[]): void {
  try {
    localStorage.setItem(CATEGORIES_STORAGE_KEY, JSON.stringify(categories));
  } catch (err) {
    console.error('Failed to save categories to localStorage', err);
  }
}

export function exportTasksToJSON(tasks: Task[]): void {
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(tasks, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `acubi_tasks_${new Date().toISOString().split('T')[0]}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

export function importTasksFromJSON(file: File): Promise<Task[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = JSON.parse(content);
        if (Array.isArray(parsed)) {
          resolve(parsed);
        } else {
          reject(new Error('Invalid task file format: expected an array'));
        }
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
}
