import { RotateCcw, X } from 'lucide-react';

interface UndoToastProps {
  message: string;
  onUndo: () => void;
  onDismiss: () => void;
}

export function UndoToast({ message, onUndo, onDismiss }: UndoToastProps) {
  return (
    <div className="fixed bottom-24 sm:bottom-8 left-4 sm:left-auto sm:right-28 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl bg-[#FBF9F2] text-[#2E2741] shadow-2xl border border-[#DDD6EC] max-w-sm">
      <span className="text-xs truncate flex-1 font-mono text-[#2E2741]">{message}</span>
      <button
        onClick={onUndo}
        className="px-2.5 py-1 text-xs font-mono font-bold text-white bg-[#606362] hover:bg-[#494D4B] rounded-lg flex items-center gap-1 transition-all cursor-pointer shadow-2xs"
      >
        <RotateCcw className="h-3 w-3" />
        <span>Undo</span>
      </button>
      <button
        onClick={onDismiss}
        className="p-1 text-[#766E87] hover:text-[#2E2741] rounded-md transition-colors cursor-pointer"
      >
        <X className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
