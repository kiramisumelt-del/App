import { useState } from 'react';
import { X, Bell, AlarmClock, Calendar, Check, Send, Sparkles } from 'lucide-react';
import { AppNotification } from '../types/todo';
import { 
  getNotificationPermission, 
  requestNotificationPermission, 
  sendBrowserNotification 
} from '../utils/notifications';
import { CloverIcon } from './CloverIcon';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: AppNotification[];
  onSelectTask: (taskId: string) => void;
}

export function NotificationCenter({
  isOpen,
  onClose,
  notifications,
  onSelectTask,
}: NotificationCenterProps) {
  const [permission, setPermission] = useState<NotificationPermission>(getNotificationPermission());
  const [testSent, setTestSent] = useState(false);

  if (!isOpen) return null;

  const handleEnableBrowserNotifications = async () => {
    const granted = await requestNotificationPermission();
    setPermission(granted ? 'granted' : 'denied');
    if (granted) {
      sendBrowserNotification('Task Matrix Alert', {
        body: 'Alerts active for scheduled tasks.',
      });
    }
  };

  const handleSendTestNotification = () => {
    sendBrowserNotification('Task Matrix Alert', {
      body: 'Notifications are connected.',
    });
    setTestSent(true);
    setTimeout(() => setTestSent(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2E2741]/40 backdrop-blur-xs">
      <div className="relative w-full max-w-md bg-[#FBF9F2] rounded-3xl border border-[#DDD6EC] shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 flex items-center justify-between border-b border-[#DDD6EC]">
          <div className="flex items-center gap-2">
            <CloverIcon className="w-4 h-4 text-[#E7D1DA]" />
            <h3 className="font-display font-bold text-base text-[#2E2741]">
              Notifications
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#766E87] hover:text-[#2E2741] hover:bg-[#EDE9F6] transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          {/* Browser Notifications Settings Banner */}
          <div className="rounded-2xl bg-[#FFFFFF] border border-[#DDD6EC] p-4 text-xs shadow-2xs">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-semibold text-[#2E2741]">Desktop Alerts</p>
                <p className="mt-0.5 text-[11px] text-[#766E87] leading-relaxed">
                  {permission === 'granted'
                    ? 'Active. Instant alerts for due times and deadlines.'
                    : 'Enable browser notifications for reminders.'}
                </p>
              </div>

              {permission === 'granted' ? (
                <span className="shrink-0 inline-flex items-center gap-1 text-[10px] font-mono font-bold text-[#3B607A] bg-[#E6EFF5] px-2 py-0.5 rounded-md border border-[#D9E4EC]">
                  <Check className="h-3 w-3" />
                  Active
                </span>
              ) : (
                <button
                  onClick={handleEnableBrowserNotifications}
                  className="shrink-0 px-3 py-1 text-xs font-semibold rounded-xl bg-[#606362] text-white shadow-2xs hover:bg-[#494D4B] transition-colors cursor-pointer font-mono"
                >
                  Enable
                </button>
              )}
            </div>

            {permission === 'granted' && (
              <div className="mt-3 pt-2.5 border-t border-[#DDD6EC] flex items-center justify-between">
                <span className="text-[10px] text-[#766E87] font-mono">Test connection</span>
                <button
                  onClick={handleSendTestNotification}
                  className="text-[11px] font-mono font-semibold text-[#606362] hover:text-[#2E2741] underline transition-colors cursor-pointer flex items-center gap-1"
                >
                  <Send className="h-3 w-3" />
                  <span>{testSent ? 'Sent' : 'Ping Alert'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Active Task Reminders */}
          <div>
            <h4 className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#766E87] mb-2 px-1">
              Alerts ({notifications.length})
            </h4>

            {notifications.length === 0 ? (
              <div className="py-6 text-center text-xs text-[#766E87] font-mono">
                <Sparkles className="h-5 w-5 text-[#E7D1DA] mx-auto mb-1.5" />
                All clear. No pending alerts.
              </div>
            ) : (
              <div className="space-y-2">
                {notifications.map((notif) => (
                  <div
                    key={notif.id}
                    onClick={() => {
                      onSelectTask(notif.taskId);
                      onClose();
                    }}
                    className={`p-3 rounded-xl border text-xs cursor-pointer transition-colors shadow-2xs ${
                      notif.type === 'overdue'
                        ? 'bg-[#FDECEF] border-[#F6BCC5] hover:bg-[#FCE3E7]'
                        : 'bg-[#FFFFFF] border-[#DDD6EC] hover:bg-[#FAF7F2]'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 mb-1">
                      {notif.type === 'overdue' ? (
                        <AlarmClock className="h-3.5 w-3.5 text-[#D44355]" />
                      ) : (
                        <Calendar className="h-3.5 w-3.5 text-[#3B607A]" />
                      )}
                      <span
                        className={`font-semibold ${
                          notif.type === 'overdue' ? 'text-[#A02535]' : 'text-[#2E2741]'
                        }`}
                      >
                        {notif.type === 'overdue' ? 'Overdue' : 'Due Today'}
                      </span>
                      <span className="text-[10px] text-[#766E87] ml-auto font-mono">
                        {notif.date}
                      </span>
                    </div>
                    <p className="font-medium text-[#2E2741] truncate">{notif.taskTitle}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#DDD6EC] bg-[#FAF7F2] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-mono font-semibold text-[#766E87] hover:text-[#2E2741] rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
